<div class="card">
    <div class="card-header text-white bg-info">
        <h5 class="oi oi-pie-menu"> Carga R&aacute;pida</h5>
    </div>
    <div class="card-body">
        <a title="" href="">
            <span class="btn btn-outline-info btn-block btn-lg oi oi-person"> Alumno</span>
        </a>
        <div>&nbsp;</div>
        <a title="" href="">
            <span class="btn btn-outline-info btn-block btn-lg oi oi-people"> Familiar</span>
        </a>
        <div>&nbsp;</div>
        <a title="" href="">
            <span class="btn btn-outline-info btn-block btn-lg oi oi-list-rich"> Entrevista</span>
        </a>
    </div>
</div>
