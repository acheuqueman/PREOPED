<div class="card">
    <div class="card-header text-white bg-secondary">
        <h5 class="oi oi-cog"> Configuraciones</h5>
    </div>
    <div class="card-body">
        <a title="" href="">
            <button type="button" class="btn btn-outline-secondary btn-block btn-lg">
                <span class="oi oi-cog"> Diagn&oacute;sticos</span>
            </button>
        </a>
        <div>&nbsp;</div>
        <a title="" href="">
            <button type="button" class="btn btn-outline-secondary btn-block btn-lg">
                <span class="oi oi-cog"> Carreras</span>
            </button>
        </a>
        <div>&nbsp;</div>
        <a title="" href="">
            <button type="button" class="btn btn-outline-secondary btn-block btn-lg">
                <span class="oi oi-cog"> Asignaturas</span>
            </button>
        </a>
        <div>&nbsp;</div>
        <a title="" href="">
            <span class="btn btn-outline-secondary btn-block btn-lg oi oi-graph"> Informes</span>
        </a>
    </div>
</div>
