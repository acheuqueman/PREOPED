<div class="card">
    <div class="card-header">
        <h4 class="oi oi-key">Usuario</h4>
    </div>
    <div class="card-body">
        <p>Bienvenid@, Eder.</p>
        <a href="../uargflow/salir.php">
            <button type="button" class="btn-outline-danger btn-block btn-lg">
                <span class="oi oi-account-logout">
                    Salir
                </span>
            </button>
        </a>
    </div>
</div>
